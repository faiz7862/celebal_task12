### Api for house price prediction App
<img src = "https://github.com/user-attachments/assets/08d21008-6987-440b-8dff-ce2e8df9f347">
